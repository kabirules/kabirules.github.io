// mongo-init.js

db = db.getSiblingDB('inditex');
db.products.insertMany([
  {
      "id": 1,
      "name": "V-NECH BASIC SHIRT",
      "sales_units": 100,
      "stock_s": 4,
      "stock_m": 9,
      "stock_l": 0,
      "category_id": 1
    },
       {
         "id": 2,
         "name": "CONTRASTING FABRIC T-SHIRT",
         "sales_units": 50,
         "stock_s": 35,
         "stock_m": 9,
         "stock_l": 9,
         "category_id": 1
       },
       {
         "id": 3,
         "name": "RAISED PRINT T-SHIRT",
         "sales_units": 80,
         "stock_s": 20,
         "stock_m": 2,
         "stock_l": 20,
         "category_id": 1
       },
       {
         "id": 4,
         "name": "PLEATED T-SHIRT",
         "sales_units": 3,
         "stock_s": 25,
         "stock_m": 30,
         "stock_l": 10,
         "category_id": 1
       },
       {
         "id": 5,
         "name": "CONTRASTING LACE T-SHIRT",
         "sales_units": 650,
         "stock_s": 0,
         "stock_m": 1,
         "stock_l": 0,
         "category_id": 1
       },
       {
         "id": 6,
         "name": "SLOGAN T-SHIRT",
         "sales_units": 20,
         "stock_s": 9,
         "stock_m": 2,
         "stock_l": 5,
         "category_id": 1
       }
]);