package com.javifont.inditex.product.infrastructure.controller;

import com.javifont.inditex.product.application.ProductService;
import com.javifont.inditex.product.domain.ProductSortingCriteria;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping(value = "/api/v1/products")
public class ProductController {

    private ProductService productService;

    public ProductController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping
    @Operation(summary = "Get all products")
    public List<ProductDTO> getAllProducts() {
        return productService.findAll();
    }

    @PostMapping("sorted")
    @Operation(summary = "Get all products sorted by weighted metrics")
    public List<ProductDTO> getAllProductsSorted(
            @RequestBody List<ProductSortingCriteria> sortingCriteriaList) {
        return productService.findAllSorted(sortingCriteriaList);
    }
}
