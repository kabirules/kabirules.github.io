package com.javifont.inditex.product.domain;

import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;

public class StockRatioMetric implements ProductMetricStrategy {
    @Override
    public double getMetricValue(ProductDTO productDTO) {
        return productDTO.getStockRatio();
    }
}
