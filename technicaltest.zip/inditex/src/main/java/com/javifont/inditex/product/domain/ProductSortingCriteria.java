package com.javifont.inditex.product.domain;

import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class ProductSortingCriteria {
    private ProductMetricStrategy metricStrategy;
    private double                weight;

    public ProductSortingCriteria(ProductMetricStrategy metricStrategy, double weight) {
        this.metricStrategy = metricStrategy;
        this.weight         = weight;
    }

    public double getWeightedMetricValue(ProductDTO productDTO) {
        return metricStrategy.getMetricValue(productDTO) * weight;
    }
}
