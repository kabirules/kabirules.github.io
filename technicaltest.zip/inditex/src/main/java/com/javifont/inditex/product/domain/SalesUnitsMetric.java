package com.javifont.inditex.product.domain;

import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;

public class SalesUnitsMetric implements ProductMetricStrategy {
    @Override
    public double getMetricValue(ProductDTO productDTO) {
        return productDTO.getSalesUnits();
    }
}