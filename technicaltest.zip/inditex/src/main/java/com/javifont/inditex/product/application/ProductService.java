package com.javifont.inditex.product.application;

import com.javifont.inditex.product.domain.Product;
import com.javifont.inditex.product.domain.ProductSortingCriteria;
import com.javifont.inditex.product.domain.ProductSortingCriteriaBuilder;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import com.javifont.inditex.product.infrastructure.repository.ProductRepository;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final ProductMapper     productMapper;

    public ProductService(ProductRepository productRepository, ProductMapper productMapper) {
        this.productRepository = productRepository;
        this.productMapper     = productMapper;
    }

    public List<ProductDTO> findAll() {
        return productMapper.toProductDTOList(productRepository.findAll());
    }

    public List<ProductDTO> findAllSorted(List<ProductSortingCriteria> sortingCriteriaList) {

        List<Product>    allProductList    = productRepository.findAll();
        List<ProductDTO> allProductDTOList = productMapper.toProductDTOList(allProductList);
        return getSortedProducts(allProductDTOList, sortingCriteriaList);
    }

    public List<ProductDTO> getSortedProducts(List<ProductDTO> productList, List<ProductSortingCriteria> sortingCriteriaList) {
        ProductSortingCriteriaBuilder sortingCriteriaBuilder = new ProductSortingCriteriaBuilder(sortingCriteriaList);
        return sortingCriteriaBuilder.sortProducts(productList);
    }
}
