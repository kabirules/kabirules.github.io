package com.javifont.inditex.product.domain;

import com.fasterxml.jackson.annotation.JsonSubTypes;
import com.fasterxml.jackson.annotation.JsonTypeInfo;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;

@JsonTypeInfo(use = JsonTypeInfo.Id.NAME, property = "type")
@JsonSubTypes({
        @JsonSubTypes.Type(value = SalesUnitsMetric.class, name = "unitsSold"),
        @JsonSubTypes.Type(value = StockRatioMetric.class, name = "stockRatio")
})
public interface ProductMetricStrategy {
    double getMetricValue(ProductDTO productDTO);
}
