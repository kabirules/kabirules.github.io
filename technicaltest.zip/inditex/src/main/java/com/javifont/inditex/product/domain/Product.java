package com.javifont.inditex.product.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.data.mongodb.core.mapping.Field;

@Data
@Builder
@Document(collection = "products")
@NoArgsConstructor
@AllArgsConstructor
public class Product {
    @Id
    private String  id;
    @Field("id")
    private Long    productId;
    private String  name;
    @Field("sales_units")
    private Integer salesUnits;
    @Field("stock_s")
    private Integer stockS;
    @Field("stock_m")
    private Integer stockM;
    @Field("stock_l")
    private Integer stockL;
    @Field("category_id")
    private Long    categoryId;
}
