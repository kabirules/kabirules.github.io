package com.javifont.inditex.product.domain;

import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class ProductSortingCriteriaBuilder {
    private List<ProductSortingCriteria> sortingCriteriaList;

    public ProductSortingCriteriaBuilder(List<ProductSortingCriteria> sortingCriteriaList) {
        this.sortingCriteriaList = sortingCriteriaList;
    }

    // TODO passing a parameter to decide ascending or descending sorting
    public List<ProductDTO> sortProducts(List<ProductDTO> productDTOList) {
        return productDTOList.stream()
                .sorted(Comparator.comparingDouble(productDTO ->
                        sortingCriteriaList.stream()
                                .mapToDouble(criteria -> criteria.getWeightedMetricValue(productDTO) * -1)
                                .sum()))
                .collect(Collectors.toList());
    }
}
