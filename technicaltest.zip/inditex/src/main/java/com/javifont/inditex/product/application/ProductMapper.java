package com.javifont.inditex.product.application;

import com.javifont.inditex.product.domain.Product;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface ProductMapper {

    @Mapping(source = "productId", target = "id")
    ProductDTO toProductDTO(Product product);

    List<ProductDTO> toProductDTOList(List<Product> productList);
}
