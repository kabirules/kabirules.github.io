package com.javifont.inditex.product.infrastructure.controller.DTO;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.javifont.inditex.product.domain.Product;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

/**
 * DTO for {@link Product}
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ProductDTO implements Serializable {
    private Long    id;
    private String  name;
    private Integer salesUnits;
    private Integer stockS;
    private Integer stockM;
    private Integer stockL;


    // FIXME Is this the correct way to calculate ratio??
    @JsonIgnore
    public double getStockRatio2() {
        int sizesWithStock  = 0;
        int NUMBER_OF_SIZES = 3;
        if (stockS != null && stockS > 0) {
            sizesWithStock++;
        }
        if (stockM != null && stockM > 0) {
            sizesWithStock++;
        }
        if (stockL != null && stockL > 0) {
            sizesWithStock++;
        }
        return (double) sizesWithStock / NUMBER_OF_SIZES;
    }

    @JsonIgnore
    public double getStockRatio() {
        return stockS + stockM + stockL;
    }
}