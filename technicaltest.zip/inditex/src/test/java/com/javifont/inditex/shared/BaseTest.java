package com.javifont.inditex.shared;

import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;

import java.util.Arrays;
import java.util.List;

public class BaseTest {

    public List<ProductDTO> getMockProductDTOList() {
        List<ProductDTO> mockProductList = Arrays.asList(
                new ProductDTO(1L, "V-NECH BASIC SHIRT", 100, 4, 9, 0),
                new ProductDTO(2L, "CONTRASTING FABRIC T-SHIRT", 50, 35, 9, 9),
                new ProductDTO(3L, "RAISED PRINT T-SHIRT", 80, 20, 2, 20),
                new ProductDTO(4L, "PLEATED T-SHIRT", 3, 25, 30, 10),
                new ProductDTO(5L, "CONTRASTING LACE T-SHIRT", 650, 0, 1, 0),
                new ProductDTO(6L, "SLOGAN T-SHIRT", 20, 9, 2, 5));
        return mockProductList;
    }
}
