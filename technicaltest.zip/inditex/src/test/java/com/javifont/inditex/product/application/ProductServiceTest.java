package com.javifont.inditex.product.application;

import com.javifont.inditex.product.domain.ProductSortingCriteria;
import com.javifont.inditex.product.domain.SalesUnitsMetric;
import com.javifont.inditex.product.domain.StockRatioMetric;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import com.javifont.inditex.product.infrastructure.repository.ProductRepository;
import com.javifont.inditex.shared.BaseTest;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.util.Arrays;
import java.util.List;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

class ProductServiceTest extends BaseTest {

    List<ProductDTO> mockProductDTOList;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private ProductMapper productMapper;

    @InjectMocks
    private ProductService productService;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);

        mockProductDTOList = getMockProductDTOList();
        when(productRepository.findAll()).thenReturn(List.of());
        when(productMapper.toProductDTOList(List.of())).thenReturn(mockProductDTOList);
    }

    @Test
    void testFindAll() {
        List<ProductDTO> result = productService.findAll();
        assertEquals(mockProductDTOList, result);
    }

    @Test
    void testFindAllSortedBySalesUnits() {
        // Arrange
        List<ProductSortingCriteria> sortingCriteriaList = Arrays.asList(new ProductSortingCriteria(new SalesUnitsMetric(), 1));

        // Act
        List<ProductDTO> result = productService.findAllSorted(sortingCriteriaList);

        // Asserts
        assertProductListSortedBySalesUnits(result);
        assertEquals(650, result.get(0).getSalesUnits());
        assertEquals(100, result.get(1).getSalesUnits());
        assertEquals(80, result.get(2).getSalesUnits());
        assertEquals(50, result.get(3).getSalesUnits());
        assertEquals(20, result.get(4).getSalesUnits());
        assertEquals(3, result.get(5).getSalesUnits());
    }

    @Test
    void testFindAllSortedBySalesUnitsAndStockRatioWithSameWeight() {
        // Arrange
        double weight = 1;
        List<ProductSortingCriteria> sortingCriteriaList = Arrays.asList(
                new ProductSortingCriteria(new SalesUnitsMetric(), weight),
                new ProductSortingCriteria(new StockRatioMetric(), weight)
        );

        // Act
        List<ProductDTO> result = productService.findAllSorted(sortingCriteriaList);

        // Asserts
        assertProductListSortedByMultipleCriteria(result, weight, weight);
        assertEquals(5, result.get(0).getId());
        assertEquals(3, result.get(1).getId());
        assertEquals(1, result.get(2).getId());
        assertEquals(2, result.get(3).getId());
        assertEquals(4, result.get(4).getId());
        assertEquals(6, result.get(5).getId());
    }

    @Test
    void testFindAllSortedBySalesUnitsAndStockRatioWithDifferentWeight() {
        // Arrange
        double weight1 = 1;
        double weight2 = 100;
        List<ProductSortingCriteria> sortingCriteriaList = Arrays.asList(
                new ProductSortingCriteria(new SalesUnitsMetric(), weight1),
                new ProductSortingCriteria(new StockRatioMetric(), weight2)
        );

        // Act
        List<ProductDTO> result = productService.findAllSorted(sortingCriteriaList);

        // Asserts
        assertProductListSortedByMultipleCriteria(result, weight1, weight2);
        assertEquals(4, result.get(0).getId());
        assertEquals(2, result.get(1).getId());
        assertEquals(3, result.get(2).getId());
        assertEquals(6, result.get(3).getId());
        assertEquals(1, result.get(4).getId());
        assertEquals(5, result.get(5).getId());
    }

    @Test
    void testFindAllSortedBySalesUnitsAndStockRatioWithAZeroWeight() {
        // Arrange
        double weight1 = 1;
        double weight2 = 0;
        List<ProductSortingCriteria> sortingCriteriaList = Arrays.asList(
                new ProductSortingCriteria(new SalesUnitsMetric(), weight1),
                new ProductSortingCriteria(new StockRatioMetric(), weight2)
        );

        // Act
        List<ProductDTO> result = productService.findAllSorted(sortingCriteriaList);

        // Asserts
        assertProductListSortedByMultipleCriteria(result, weight1, weight2);
        assertEquals(5, result.get(0).getId());
        assertEquals(1, result.get(1).getId());
        assertEquals(3, result.get(2).getId());
        assertEquals(2, result.get(3).getId());
        assertEquals(6, result.get(4).getId());
        assertEquals(4, result.get(5).getId());
    }

    @Test
    void testFindAllSortedBySalesUnitsAndStockRatioWithTwoZeroWeight() {
        // Arrange
        double weight = 0;
        List<ProductSortingCriteria> sortingCriteriaList = Arrays.asList(
                new ProductSortingCriteria(new SalesUnitsMetric(), weight),
                new ProductSortingCriteria(new StockRatioMetric(), weight)
        );

        // Act
        List<ProductDTO> result = productService.findAllSorted(sortingCriteriaList);

        // Asserts
        assertProductListSortedByMultipleCriteria(result, weight, weight);
        assertEquals(1, result.get(0).getId());
        assertEquals(2, result.get(1).getId());
        assertEquals(3, result.get(2).getId());
        assertEquals(4, result.get(3).getId());
        assertEquals(5, result.get(4).getId());
        assertEquals(6, result.get(5).getId());
    }

    private void assertProductListSortedBySalesUnits(List<ProductDTO> productList) {
        assertEquals(mockProductDTOList.size(), productList.size());

        for (int i = 0; i < productList.size() - 1; i++) {
            assertTrue(productList.get(i).getSalesUnits() >= productList.get(i + 1).getSalesUnits());
        }
    }

    private void assertProductListSortedByMultipleCriteria(List<ProductDTO> productList, double weight1, double weight2) {
        assertEquals(mockProductDTOList.size(), productList.size());

        for (int i = 0; i < productList.size() - 1; i++) {
            double value1 = (productList.get(i).getSalesUnits() * weight1) + (productList.get(i).getStockRatio() * weight2);
            double value2 = (productList.get(i + 1).getSalesUnits() * weight1) + (productList.get(i + 1).getStockRatio() * weight2);
            assertTrue(value1 >= value2);
        }
    }
}
