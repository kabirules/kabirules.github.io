package com.javifont.inditex.product.infrastructure.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.javifont.inditex.product.application.ProductService;
import com.javifont.inditex.product.domain.ProductSortingCriteria;
import com.javifont.inditex.product.infrastructure.controller.DTO.ProductDTO;
import com.javifont.inditex.shared.BaseTest;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.Arrays;
import java.util.List;

import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@SpringBootTest
@AutoConfigureMockMvc
class ProductControllerTest extends BaseTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @MockBean
    private ProductService productService;

    @Test
    void getAllProducts() throws Exception {

        final List<ProductDTO> mockProductList = getMockProductDTOList();
        when(productService.findAll()).thenReturn(mockProductList);

        mockMvc.perform(get("/api/v1/products"))
                .andExpect(status().isOk());

        for (int i = 0; i < mockProductList.size(); i++) {
            ProductDTO product = mockProductList.get(i);
            performJsonPathVerifications("/api/v1/products", i, product);
        }
    }

    @Test
    void getAllProductsSorted() throws Exception {
        final List<ProductDTO> mockProductList = getMockProductDTOList();
        when(productService.findAllSorted(Arrays.asList(new ProductSortingCriteria(), new ProductSortingCriteria())))
                .thenReturn(mockProductList);

        mockMvc.perform(post("/api/v1/products/sorted")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(Arrays.asList(new ProductSortingCriteria(), new ProductSortingCriteria()))))
                .andExpect(status().isOk());
    }

    private void performJsonPathVerifications(String endpoint, int index, ProductDTO product) throws Exception {
        mockMvc.perform(get(endpoint))
                .andExpect(jsonPath("$[" + index + "].id").value(product.getId()))
                .andExpect(jsonPath("$[" + index + "].name").value(product.getName()))
                .andExpect(jsonPath("$[" + index + "].salesUnits").value(product.getSalesUnits()))
                .andExpect(jsonPath("$[" + index + "].stockS").value(product.getStockS()))
                .andExpect(jsonPath("$[" + index + "].stockM").value(product.getStockM()))
                .andExpect(jsonPath("$[" + index + "].stockL").value(product.getStockL()));
    }
}